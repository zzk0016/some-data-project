import pandas as pd
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus']=False
rawdata=pd.read_excel('data.xls',sheet_name="guangdong")
year=rawdata['年份'].values
label2=rawdata.iloc[:,-1].values
y=[31598.146,30642.467,29403.365,28605.58,27690.82,26676.377,
   26098.793,24845.648,23691.31,22835.887,21354.756,19243.113,
   17113.982,14599.964,12526.815,10706.424,9858.737,8656.887,
   8282.767,7938.9785,7517.2734,7098.8047,6536.042,6076.125 ]
x=[0]*len(y)
for i in range(len(y)):
   x[i]=(label2[i]-y[i])/label2[i]
x=pd.DataFrame(x)
x.to_csv("x.csv")