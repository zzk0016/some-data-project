import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus']=False
province="yunnan"
rawdata=pd.read_excel('rawdata.xls',sheet_name=province)
data_cr=rawdata.corr()
plt.figure(figsize=(12,10))
fig=sns.heatmap(data_cr,annot=True,fmt='.2g',linewidths=.1)
plt.title("1993-2017年云南省特征相关性热图")
province=province+".png"
plt.savefig(province, bbox_inches = 'tight')
plt.show()


