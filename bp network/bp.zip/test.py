import pandas as pd
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import tensorflow as tf

rawdata=pd.read_excel('data.xls',sheet_name="guangdong")
predata=pd.read_excel('predata.xls',sheet_name="guangdong")

data=rawdata.iloc[:,:-2].values
label1=rawdata.iloc[:,-2:-1].values
label2=rawdata.iloc[:,-1].values
data3=predata.values

train_data,test_data,train_label,test_label=train_test_split(data,label1,test_size=0.08)
model=tf.keras.Sequential()
model.add(tf.keras.layers.Dense(30,input_shape=(12,)))
model.add(tf.keras.layers.Dense(13,activation='relu'))
model.add(tf.keras.layers.Dense(13,activation='relu'))
model.add(tf.keras.layers.Dense(13,activation='relu'))
model.add(tf.keras.layers.Dense(13,activation='relu'))
model.add(tf.keras.layers.Dense(1))
model.compile(optimizer='Adam',loss='mse')
history=model.fit(data,label2,epochs=10000)

y=model.predict(data,batch_size=1)
y=y[:,0]
year=rawdata['年份'].values
plt.plot(year,label2,'red',linestyle='--',label="实际值")
#plt.plot(year,y)
plt.xlabel("年份")
plt.ylabel("能源需求")
plt.show()
print(y)






