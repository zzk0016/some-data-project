import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget,QMessageBox,QStatusBar
from PyQt5.QtGui import QRegExpValidator,QStandardItemModel,QStandardItem,QIcon
from PyQt5.QtCore import Qt,QRegExp
import matplotlib
matplotlib.use('Qt5Agg')
from main import *
from login import *
from prepare import *
from manage import *
from search import *
from plot import *
from datachange import *
from datadelete import *
import mysql
import pandas as pd
import scoregirl
import scoreboy
import time1
import re
import numpy as np
pd.options.mode.chained_assignment = None
pp=1
class loginWindow(QWidget,Ui_login):
    def __init__(self, parent=None):
        super(loginWindow, self).__init__(parent)
        self.setupUi(self)
        regx = QRegExp("^[a-zA-Z][0-9A-Za-z]{7}$")
        validator = QRegExpValidator(regx, self.le_password)
        self.le_password.setValidator(validator)
        self.bt_login.clicked.connect(self.ok)
        self.bt_quit.clicked.connect(self.cancel)
        self.setWindowFlags(Qt.FramelessWindowHint)

    def ok(self):
        text=self.le_password.text()
        db=mysql.con()
        cursor = db.cursor()
        sql="select * from account where account='"+self.le_account.text()+"'"
        cursor.execute(sql)
        data = cursor.fetchone()
        db.close()
        if len(text)==0:
            QMessageBox.warning(self, "警告", "密码为空")
        elif len(text)<6:
            QMessageBox.warning(self, "警告", "密码长度低于6位")
        elif data:
            if text==data[1]:
                global pp
                if text[0]=='S':
                    pp=1
                elif text[0]=='T':
                    pp=2
                elif text[0]=='A':
                    pp=3
                QMessageBox.information(self, "提示", "登录成功")
                main.st()
                main.show()
                self.close()
            else:
                QMessageBox.warning(self, "警告", "密码错误")
        elif not data:
            QMessageBox.warning(self, "警告", "该账号不存在")
    def cancel(self):
        self.close()

class prepareWindow(QWidget,Ui_prepare):
    def __init__(self, parent=None):
        super(prepareWindow, self).__init__(parent)
        self.setupUi(self)
        self.data=()
        self.boy=()
        self.girl=()
        self.account=()
        self.bt_in.clicked.connect(self.datain)
        self.bt_prepare.clicked.connect(self.prepare)
        self.bt_out.clicked.connect(self.dataout)
    def datain(self):
        text=self.le_in.text()
        year=self.cb_year.currentText()
        if text:
            self.data = pd.read_excel(text)
            if self.data is not None:
                ligong = ['材料科学与工程', '地理信息科学', '地球物理学', '地质工程', '地质学', '电子信息工程',
                          '环境工程', '计算机科学与技术', '数学与应用数学', '土木工程', '物理学', '自动化', '测绘工程',
                          '地质学类', '软件工程', '安全工程']
                jingguan = ['财务管理', '公共事业管理', '国际经济与贸易', '会计学', '经济学', '统计学', '信息管理与信息系统', '行政管理']
                wenzhe = ['法学', '思想政治教育', '英语']
                yiti = ['广播电视学', '社会体育', '音乐学', '社会体育指导与管理']
                for i in range(len(self.data)):
                    self.data['班级名称'][i] = re.sub('\(.*\)', '', self.data['班级名称'][i])
                    self.data['班级名称'][i] = re.sub('\uff08.*\uff09', '', self.data['班级名称'][i])
                    if self.data['班级名称'][i] in ligong:
                        self.data['班级名称'][i] = '理工类'
                    elif self.data['班级名称'][i] in jingguan:
                        self.data['班级名称'][i] = '经管类'
                    elif self.data['班级名称'][i] in wenzhe:
                        self.data['班级名称'][i] = '文哲类'
                    elif self.data['班级名称'][i] in yiti:
                        self.data['班级名称'][i] = '艺体类'
                    if self.data['年级编号'][i] == 44:
                        self.data['年级编号'][i] = 4
                    elif self.data['年级编号'][i] == 43:
                        self.data['年级编号'][i] = 3
                    elif self.data['年级编号'][i] == 42:
                        self.data['年级编号'][i] = 2
                    elif self.data['年级编号'][i] == 41:
                        self.data['年级编号'][i] = 1
                self.data = self.data.rename(columns={'学籍号': '账号', '班级名称': '专业', '民族代码': '民族'})
            else:
                QMessageBox.warning(self, "警告", '地址错误')
        else:
            QMessageBox.warning(self, "警告", "请输入地址")
    def prepare(self):
        year=self.cb_year.currentText()
        if self.data is not None:
            self.boy = self.data[self.data['性别'] == '男']
            self.girl = self.data[self.data['性别'] == '女']
            self.boy = self.boy.reset_index(drop=True)
            self.boy = self.boy.drop(columns=['一分钟仰卧起坐', '800米跑', '性别'])
            self.girl = self.girl.reset_index(drop=True)
            self.girl = self.girl.drop(columns=['引体向上', '1000米跑', '性别'])

            for i in range(len(self.boy)):
                self.boy['1000米跑'][i] = time1.time(self.boy['1000米跑'][i])
                self.boy['账号'][i] = 'S1' + str(self.boy['账号'][i])
            for i in range(len(self.girl)):
                self.girl['800米跑'][i] = time1.time(self.girl['800米跑'][i])
                self.girl['账号'][i] = 'S2' + str(self.girl['账号'][i])

            boyID = range(1, len(self.boy) + 1)
            self.boy['ID'] = boyID
            girlID = range(1, len(self.girl) + 1)
            self.girl['ID'] = girlID

            boybmi = [0] * len(self.boy)
            boyfhl = [0] * len(self.boy)
            boywsm = [0] * len(self.boy)
            boyzwt = [0] * len(self.boy)
            boyldt = [0] * len(self.boy)
            boyytx = [0] * len(self.boy)
            boycp = [0] * len(self.boy)
            boyscore = [0] * len(self.boy)
            for i in range(len(self.boy)):
                boybmi[i] = scoreboy.bmis(self.boy['身高'][i], self.boy['体重'][i])
                boyfhl[i] = scoreboy.feihuoliangs(self.boy['年级编号'][i], self.boy['肺活量'][i])
                boywsm[i] = scoreboy.duanpaos(self.boy['年级编号'][i], self.boy['50米跑'][i])
                boyzwt[i] = scoreboy.zuoweitis(self.boy['年级编号'][i], self.boy['坐位体前屈'][i])
                boyldt[i] = scoreboy.lidingtiaos(self.boy['年级编号'][i], self.boy['立定跳远'][i])
                boyytx[i] = scoreboy.yintixiangshangs(self.boy['年级编号'][i], self.boy['引体向上'][i])
                boycp[i] = scoreboy.changpaos(self.boy['年级编号'][i], self.boy['1000米跑'][i])
                boyscore[i] = boybmi[i] + boyfhl[i] + boywsm[i] + boyzwt[i] + boyldt[i] + boyytx[i] + boycp[i]

            self.boy['BMI成绩'] = boybmi
            self.boy['肺活量成绩'] = boyfhl
            self.boy['50米跑成绩'] = boywsm
            self.boy['坐位体前屈成绩'] = boyzwt
            self.boy['立定跳远成绩'] = boyldt
            self.boy['引体向上成绩'] = boyytx
            self.boy['1000米跑成绩'] = boycp
            self.boy['总成绩'] = boyscore

            order = ['ID', '年级编号', '专业', '账号', '民族', '姓名', '身高', '体重', 'BMI成绩', '肺活量', '肺活量成绩',
                     '50米跑', '50米跑成绩', '立定跳远', '立定跳远成绩', '坐位体前屈', '坐位体前屈成绩', '1000米跑',
                     '1000米跑成绩', '引体向上', '引体向上成绩', '总成绩']
            self.boy = self.boy[order]
            girlbmi = [0] * len(self.girl)
            girlfhl = [0] * len(self.girl)
            girlwsm = [0] * len(self.girl)
            girlzwt = [0] * len(self.girl)
            girlldt = [0] * len(self.girl)
            girlywq = [0] * len(self.girl)
            girlcp = [0] * len(self.girl)
            girlscore = [0] * len(self.girl)
            for i in range(len(self.girl)):
                girlbmi[i] = scoregirl.bmis(self.girl['身高'][i], self.girl['体重'][i])
                girlfhl[i] = scoregirl.feihuoliangs(self.girl['年级编号'][i], self.girl['肺活量'][i])
                girlwsm[i] = scoregirl.duanpaos(self.girl['年级编号'][i], self.girl['50米跑'][i])
                girlzwt[i] = scoregirl.zuoweitis(self.girl['年级编号'][i], self.girl['坐位体前屈'][i])
                girlldt[i] = scoregirl.lidingtiaos(self.girl['年级编号'][i], self.girl['立定跳远'][i])
                girlywq[i] = scoregirl.yangwoqizuos(self.girl['年级编号'][i], self.girl['一分钟仰卧起坐'][i])
                girlcp[i] = scoregirl.changpaos(self.girl['年级编号'][i], self.girl['800米跑'][i])
                girlscore[i] = girlbmi[i] + girlfhl[i] + girlwsm[i] + girlzwt[i] + girlldt[i] + girlywq[i] + girlcp[i]
            self.girl['BMI成绩'] = girlbmi
            self.girl['肺活量成绩'] = girlfhl
            self.girl['50米跑成绩'] = girlwsm
            self.girl['坐位体前屈成绩'] = girlzwt
            self.girl['立定跳远成绩'] = girlldt
            self.girl['一分钟仰卧起坐成绩'] = girlywq
            self.girl['800米跑成绩'] = girlcp
            self.girl['总成绩'] = girlscore
            order = ['ID', '年级编号', '专业', '账号', '民族', '姓名', '身高', '体重', 'BMI成绩', '肺活量', '肺活量成绩',
                     '50米跑', '50米跑成绩', '立定跳远', '立定跳远成绩', '坐位体前屈', '坐位体前屈成绩', '800米跑',
                     '800米跑成绩', '一分钟仰卧起坐', '一分钟仰卧起坐成绩', '总成绩']
            self.girl = self.girl[order]
            self.account = self.boy['账号'].values
            self.account = np.append(self.account, self.girl['账号'].values)
            password = ['S1284987'] * len(self.account)
            permission = [1] * len(self.account)
            self.account = pd.DataFrame({'账号': self.account, '密码': password, '权限': permission})
            self.model = QStandardItemModel()
            coname = ['序号', '年级', '专业大类', '学号', '民族', '姓名', '身高', '体重', 'BMI成绩', '肺活量', '肺活量成绩',
                      '50米跑', '50米跑成绩', '立定跳远', '立定跳远成绩', '坐位体前屈', '坐位体前屈成绩', '长跑', '长跑成绩',
                      '引体向上', '引体向上成绩', '总成绩']
            self.model.setHorizontalHeaderLabels(coname)
            boy=self.boy.values
            r = len(boy)
            c = len(boy[0])
            for i in range(r):
                for j in range(c):
                    it = QStandardItem(str(boy[i][j]))
                    self.model.setItem(i, j, it)
            self.tableView.setModel(self.model)
        else:
            QMessageBox.information(self, "通知", "数据未导入")

    def dataout(self):
        text=self.le_out.text()
        year=self.cb_year.currentText()
        if self.boy is not None:
            if len(text)==0:
                add = year + "boy.xls"
                self.boy.to_excel(add, index=False)
                add = year + "girl.xls"
                self.girl.to_excel(add, index=False)
                add = year + "account.xls"
                self.account.to_excel(add, index=False)

            else:
                add = text + "/" + year + "boy.xls"
                self.boy.to_excel(add, index=False)
                add = text + "/" + year + "girl.xls"
                self.girl.to_excel(add, index=False)
                add = text + "/" + year + "account.xls"
                self.account.to_excel(add, index=False)
        else:
            QMessageBox.information(self, "提示", "暂无数据可导入")


class mainWindow(QMainWindow,Ui_MainWindow):
    def __init__(self, parent=None):
        super(mainWindow, self).__init__(parent)
        self.setupUi(self)
        self.stb=QStatusBar()
        self.setStatusBar(self.stb)
        self.mn_bangzhuwendang.triggered.connect(self.abouthelp)
        self.mn_zuozhe.triggered.connect(self.aboutzz)
        self.actionguanyuruanjian.triggered.connect(self.aboutqt)
        self.bt_search.clicked.connect(self.searchshow)
        self.bt_manage.clicked.connect(self.manageshow)
        self.bt_analysis.clicked.connect(self.plotshow)
        self.bt_quit.clicked.connect(self.quit)
        self.bt_prepare.clicked.connect(self.prepare)
    def aboutqt(self):
        QMessageBox.aboutQt(self, '关于Qt')
    def abouthelp(self):
        mb=QMessageBox(QMessageBox.NoIcon, '帮助','本系统包含数据预处理、数据查询、数据分析和数据管理等功能，可实现对数据的预处理、统计和分析。账号分为管理员、老师和学生三种，学生权限只能进行查询，而老师还可以查看数据分析，管理员可使用全部功能。'
                                                '如有需要，请联系管理员。')
        mb.exec()
    def aboutzz(self):
        mb = QMessageBox(QMessageBox.NoIcon, '关于作者', '作者为中国地质大学学生，联系邮箱为1526757433@qq.com')
        mb.exec()
    def st(self):
        global pp
        if pp == 1:
            self.stb.showMessage('当前身份为：学生')
        elif pp == 2:
            self.stb.showMessage('当前身份为：教师')
        elif pp == 3:
            self.stb.showMessage('当前身份为：管理员')
    def prepare(self):
        global pp
        if pp == 3:
            prepare.show()
        else:
            QMessageBox.warning(self, "警告", "暂无权限")
    def searchshow(self):
        search.show()
    def manageshow(self):
        global pp
        if pp==3:
            manage.show()
        else:
            QMessageBox.warning(self, "警告", "暂无权限")
    def plotshow(self):
        global pp
        if pp==1:
            QMessageBox.warning(self, "警告", "暂无权限")
        else:
            plot.show()
    def quit(self):
        sys.exit(0)
    def closeEvent(self, event):
        sys.exit(0)
class searchWindow(QMainWindow,Ui_search):
    def __init__(self, parent=None):
        super(searchWindow, self).__init__(parent)
        self.setupUi(self)
        self.bt_search.clicked.connect(self.datasearch)
        self.cb_sex.currentIndexChanged.connect(self.changeproject)
        self.bt_reset.clicked.connect(self.reset)
    def changeproject(self):
        if self.cb_sex.currentText()=='男':
            self.cb_project.addItem('引体向上成绩')
        elif self.cb_sex.currentText()=='女':
            self.cb_project.addItem('仰卧起坐成绩')
    def datasearch(self):
        year=self.cb_data.currentText()
        discipline=self.cb_discipline.currentText()
        sex=self.cb_sex.currentText()
        grade=self.cb_grade.currentText()
        account=self.le_account.text()
        name=self.le_name.text()
        project=self.cb_project.currentText()
        condition=self.le_conditon.text()
        db = mysql.con()
        cursor = db.cursor()
        sql = "select * from"
        if sex=='男':
            sql=sql+" "+year+"boy"
        else:
            sql = sql + " " + year + "girl"
        sql=sql+" where name is not null"
        if discipline=='理工类':
            sql=sql+" and discipline = '理工类'"
        elif discipline=='经管类':
            sql = sql + " and discipline = '经管类'"
        elif discipline=='文哲类':
            sql = sql + " and discipline = '文哲类'"
        elif discipline=='艺体类':
            sql = sql + " and discipline = '文哲类'"
        if grade=='大一':
            sql=sql+" and grade =1"
        elif grade=='大二':
            sql = sql + " and grade =2"
        elif grade=='大三':
            sql = sql + " and grade =3"
        elif grade == '大四':
            sql = sql + " and grade =4"
        if account:
            sql=sql+" and account = '"+account+"'"
        if name:
            sql=sql+" and name = '"+name+"'"
        if condition:
            if project=='总成绩':
                sql=sql+" and score"+condition
            elif project=='BMI成绩':
                sql=sql+" and bmis"+condition
            elif project=='肺活量成绩':
                sql = sql + " and fhls" + condition
            elif project=='50米跑成绩':
                sql = sql + " and wsms" + condition
            elif project=='坐位体前屈成绩':
                sql = sql + " and zwts" + condition
            elif project=='立定跳远成绩':
                sql = sql + " and ldts" + condition
            elif project=='长跑成绩':
                sql = sql + " and cps" + condition
            elif project == '引体向上成绩':
                sql = sql + " and ytxs" + condition
            elif project == '仰卧起坐成绩':
                sql = sql + " and ywqs" + condition
        cursor.execute(sql)
        print(sql)
        data = cursor.fetchall()
        self.model=QStandardItemModel()
        co=cursor.description
        db.close()
        if sex=='男':
            coname = ['序号','年级','专业大类','学号','民族','姓名','身高','体重','BMI成绩','肺活量','肺活量成绩',
                  '50米跑','50米跑成绩','立定跳远','立定跳远成绩','坐位体前屈','坐位体前屈成绩','长跑','长跑成绩',
                  '引体向上','引体向上成绩','总成绩']
        elif sex=='女':
            coname = ['序号', '年级', '专业大类', '学号', '民族', '姓名', '身高', '体重', 'BMI成绩', '肺活量', '肺活量成绩',
                      '50米跑', '50米跑成绩', '立定跳远', '立定跳远成绩', '坐位体前屈', '坐位体前屈成绩', '长跑', '长跑成绩',
                      '仰卧起坐', '仰卧起坐成绩', '总成绩']
        self.model.setHorizontalHeaderLabels(coname)
        if data:
            r= len(data)
            c=len(data[0])
            for i in range(r):
                for j in range(c):
                    it = QStandardItem(str(data[i][j]))
                    self.model.setItem(i, j, it)
            self.table.setModel(self.model)
        else:
            QMessageBox.warning(self, "警告", "没有该数据")

    def reset(self):
        self.cb_data.setCurrentText('2015')
        self.cb_discipline.setCurrentText('全部')
        self.cb_sex.setCurrentText('男')
        self.cb_grade.setCurrentText('全部')
        self.le_account.setText('')
        self.le_name.setText('')
        self.cb_project.setCurrentText('总成绩')

        self.model.clear()

class manageWindow(QMainWindow,Ui_manage):
    def __init__(self, parent=None):
        super(manageWindow, self).__init__(parent)
        self.setupUi(self)
        self.model = QStandardItemModel()
        self.bt_search.clicked.connect(self.datasearch)
        self.model = QStandardItemModel()
        self.bt_change.clicked.connect(self.dtchange)
        self.bt_delete.clicked.connect(self.dtdelete)
        self.bt_reset.clicked.connect(self.reset)
    def changeproject(self):
        if self.cb_sex.currentText()=='男':
            self.cb_project.addItem('引体向上成绩')
        elif self.cb_sex.currentText()=='女':
            self.cb_project.addItem('仰卧起坐成绩')
    def datasearch(self):
        year = self.cb_year.currentText()
        sex = self.cb_sex.currentText()
        account = self.le_account.text()
        project = self.cb_project.currentText()
        condition = self.le_condition.text()
        db = mysql.con()
        cursor = db.cursor()
        sql = "select * from"
        if sex=='男':
            sql=sql+" "+year+"boy"
        else:
            sql = sql + " " + year + "girl"
        sql=sql+" where name is not null"
        if account:
            sql=sql+" and account = '"+account+"'"
        g=['>','<','=','>=','<=']
        if condition:
            if condition[0] in g:
                if project == '总成绩':
                    sql = sql + " and score" + condition
                elif project == 'BMI成绩':
                    sql = sql + " and bmis" + condition
                elif project == '肺活量成绩':
                    sql = sql + " and fhls" + condition
                elif project == '50米跑成绩':
                    sql = sql + " and wsms" + condition
                elif project == '坐位体前屈成绩':
                    sql = sql + " and zwts" + condition
                elif project == '立定跳远成绩':
                    sql = sql + " and ldts" + condition
                elif project == '长跑成绩':
                    sql = sql + " and cps" + condition
                elif project == '引体向上成绩':
                    sql = sql + " and ytxs" + condition
                elif project == '仰卧起坐成绩':
                    sql = sql + " and ywqs" + condition
        cursor.execute(sql)
        data = cursor.fetchall()
        db.close()
        coname = []
        if sex=='男':
            coname = ['序号','年级','专业大类','学号','民族','姓名','身高','体重','BMI成绩','肺活量','肺活量成绩',
                  '50米跑','50米跑成绩','立定跳远','立定跳远成绩','坐位体前屈','坐位体前屈成绩','长跑','长跑成绩',
                  '引体向上','引体向上成绩','总成绩']
        elif sex=='女':
            coname = ['序号', '年级', '专业大类', '学号', '民族', '姓名', '身高', '体重', 'BMI成绩', '肺活量', '肺活量成绩',
                      '50米跑', '50米跑成绩', '立定跳远', '立定跳远成绩', '坐位体前屈', '坐位体前屈成绩', '长跑', '长跑成绩',
                      '仰卧起坐', '仰卧起坐成绩', '总成绩']
        if data:
            self.model.setHorizontalHeaderLabels(coname)
            r = len(data)
            c = len(data[0])
            for i in range(r):
                for j in range(c):
                    it = QStandardItem(str(data[i][j]))
                    self.model.setItem(i, j, it)
            self.table.setModel(self.model)
        else:
            QMessageBox.warning(self, "警告", "没有该数据")
    def reset(self):
        self.cb_year.setCurrentIndex(0)
        self.cb_sex.setCurrentIndex(0)
        self.le_account.setText('')
        self.cb_project.setCurrentText('总成绩')
        self.le_condition.setText('')
        self.model.clear()
    def dtchange(self):
        dataChange.show()
    def dtdelete(self):
        datadelete.show()

class changeWindow(QWidget,Ui_datachange):
    def __init__(self, parent=None):
        super(changeWindow, self).__init__(parent)
        self.setupUi(self)
        self.bt_search.clicked.connect(self.search)
        self.bt_change.clicked.connect(self.change)
    def search(self):
        account = self.le_account.text()
        year=self.cb_year.currentText()
        if self.cb_sex.currentText()=='男':
            sex='boy'
        else:
            sex='girl'
        if account:
            db = mysql.con()
            cursor = db.cursor()
            sql = "select * from" +" "+year+sex+" where account='"+account+"'"
            cursor.execute(sql)
            data=cursor.fetchone()
        else:
            QMessageBox.information(self, "提示", "请输入账号")
        if data:
            if data[1]==1:
                self.cb_grade.setCurrentIndex(0)
            elif data[1]==2:
                self.cb_grade.setCurrentIndex(1)
            elif data[1] == 3:
                self.cb_grade.setCurrentIndex(2)
            elif data[1] == 4:
                self.cb_grade.setCurrentIndex(3)
            if data[2]=='理工类':
                self.cb_discipline.setCurrentIndex(0)
            elif data[2]=='经管类':
                self.cb_discipline.setCurrentIndex(1)
            elif data[2]=='文哲类':
                self.cb_discipline.setCurrentIndex(2)
            elif data[2]=='艺体类':
                self.cb_discipline.setCurrentIndex(3)
            self.le_nation.setText(data[4])
            self.le_name.setText(str(data[5]))
            self.le_high.setText(str(data[6]))
            self.le_weight.setText(str(data[7]))
            self.le_fhl.setText(str(data[9]))
            self.le_wsm.setText(str(data[11]))
            self.le_ldt.setText(str(data[13]))
            self.le_cp.setText(str(data[17]))
            self.le_ytx.setText(str(data[19]))
        else:
            QMessageBox.information(self, "通知", "查找不到该数据")
    def change(self):
        account = self.le_account.text()
        year = self.cb_year.currentText()
        if self.cb_sex.currentText() == '男':
            sex = 'boy'
        else:
            sex = 'girl'
        if self.le_name.text() is not None:
            db=mysql.con()
            cursor=db.cursor()
            if self.cb_grade.currentText()=='大一':
                grade=1
            elif self.cb_grade.currentText()=='大二':
                grade=2
            elif self.cb_grade.currentText() == '大三':
                grade = 3
            elif self.cb_grade.currentText() == '大四':
                grade = 4
            sql="update"+" "+year+sex+" set grade="+str(grade)+" where account='"+account+"'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set discipline='" +self.cb_discipline.currentText()+"' where account='"+account+"'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set nation='" + self.le_nation.text() + "' where account='"+account+"'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set name='" + self.le_name.text() + "' where account='"+account+"'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set high=" + self.le_high.text() +" where account='"+account+"'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set weight=" + self.le_weight.text() + " where account='" + account + "'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set fhl=" + self.le_fhl.text() + " where account='" + account + "'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set wsm=" + self.le_wsm.text() + " where account='" + account + "'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set ldt=" + self.le_ldt.text() + " where account='" + account + "'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set cp=" + self.le_cp.text() + " where account='" + account + "'"
            cursor.execute(sql)
            db.commit()
            sql = "update" + " " + year + sex + " set ytx=" + self.le_ytx.text() + " where account='" + account + "'"
            cursor.execute(sql)
            db.commit()


class deleteWindow(QWidget,Ui_datadelete):
    def __init__(self, parent=None):
        super(deleteWindow, self).__init__(parent)
        self.setupUi(self)
        self.bt_delete.clicked.connect(self.delete)
    def delete(self):
        db=mysql.con()
        year = self.cb_year.currentText()
        account=self.le_account.text()
        if self.cb_sex.currentText() == '男':
            sex = 'boy'
        else:
            sex = 'girl'
        cursor=db.cursor()
        if account is not None:
            sql="select * from"+" "+year+sex+" where account='"+account+"'"
            cursor.execute(sql)
            data=cursor.fetchall()
            if data is not None:
                sql="DELETE FROM"+" "+year+sex+" where account='"+account+"'"
                print(sql)
                cursor.execute(sql)
                db.commit()
                QMessageBox.warning(self, "警告", "该数据已被删除")
            else:
                QMessageBox.warning(self, "警告", "该数据不存在")
        else:
            QMessageBox.information(self, "提示", "请先输入学号")


class plotWindow(QWidget,Ui_plot):
    def __init__(self, parent=None):
        super(plotWindow, self).__init__(parent)
        self.setupUi(self)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    login = loginWindow()
    main=mainWindow()
    main.setWindowIcon(QIcon("title.png"))
    prepare=prepareWindow()
    prepare.setWindowIcon(QIcon("title.png"))
    search=searchWindow()
    search.setWindowIcon(QIcon("title.png"))
    manage=manageWindow()
    manage.setWindowIcon(QIcon("title.png"))
    plot=plotWindow()
    plot.setWindowIcon(QIcon("title.png"))
    login.show()
    dataChange=changeWindow()
    dataChange.setWindowIcon(QIcon("title.png"))
    datadelete=deleteWindow()
    datadelete.setWindowIcon(QIcon("title.png"))
    sys.exit(app.exec_())