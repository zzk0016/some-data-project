import pymysql
host = 'localhost'
user = 'root'
password = 'zzxy200104030016'
name='data'
import matplotlib.pyplot as plt
def con():
    db = pymysql.connect(host=host, user=user, password=password, database=name)
    return db

if __name__ == '__main__':
    db=con()
    sql1 = "select * from 2015boy"
    cursor = db.cursor()
    cursor.execute(sql1)
    s=cursor.description
    print(s[3][0])





