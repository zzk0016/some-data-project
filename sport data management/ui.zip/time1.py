def time(a):
    b=a.split('′')
    if len(b[1])==1:
        b=int(b[0])*60+int(b[1])*10
    elif len(b[1])==2:
        b=int(b[0])*60+int(b[1])
    return b
