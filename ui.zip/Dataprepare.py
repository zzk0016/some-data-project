import re
import pandas as pd
import numpy as np
import time1
import scoreboy
import scoregirl
pd.options.mode.chained_assignment = None
def dataprepare(text):
    data = pd.read_excel(text)
    ligong = ['材料科学与工程', '地理信息科学', '地球物理学', '地质工程', '地质学', '电子信息工程',
              '环境工程', '计算机科学与技术', '数学与应用数学', '土木工程', '物理学', '自动化', '测绘工程',
              '地质学类', '软件工程', '安全工程']
    jingguan = ['财务管理', '公共事业管理', '国际经济与贸易', '会计学', '经济学', '统计学', '信息管理与信息系统', '行政管理']
    wenzhe = ['法学', '思想政治教育', '英语']
    yiti = ['广播电视学', '社会体育', '音乐学', '社会体育指导与管理']
    for i in range(len(data)):
        data['班级名称'][i] = re.sub('\(.*\)', '', data['班级名称'][i])
        data['班级名称'][i] = re.sub('\uff08.*\uff09', '', data['班级名称'][i])
        if data['班级名称'][i] in ligong:
            data['班级名称'][i] = '理工类'
        elif data['班级名称'][i] in jingguan:
            data['班级名称'][i] = '经管类'
        elif data['班级名称'][i] in wenzhe:
            data['班级名称'][i] = '文哲类'
        elif data['班级名称'][i] in yiti:
            data['班级名称'][i] = '艺体类'
        if data['年级编号'][i] == 44:
            data['年级编号'][i] = 4
        elif data['年级编号'][i] == 43:
            data['年级编号'][i] = 3
        elif data['年级编号'][i] == 42:
            data['年级编号'][i] = 2
        elif data['年级编号'][i] == 41:
            data['年级编号'][i] = 1
    data = data.rename(columns={'学籍号': '账号', '班级名称': '专业', '民族代码': '民族'})

    boy = data[data['性别'] == '男']
    girl = data[data['性别'] == '女']

    boy = boy.reset_index(drop=True)
    boy = boy.drop(columns=['一分钟仰卧起坐', '800米跑', '性别'])
    girl = girl.reset_index(drop=True)
    girl = girl.drop(columns=['引体向上', '1000米跑', '性别'])

    for i in range(len(boy)):
        boy['1000米跑'][i] = time1.time(boy['1000米跑'][i])
        boy['账号'][i] = 'S1' + str(boy['账号'][i])
    for i in range(len(girl)):
        girl['800米跑'][i] = time1.time(girl['800米跑'][i])
        girl['账号'][i] = 'S2' + str(girl['账号'][i])

    boyID = range(1, len(boy) + 1)
    boy['ID'] = boyID
    girlID = range(1, len(girl) + 1)
    girl['ID'] = girlID

    boybmi = [0] * len(boy)
    boyfhl = [0] * len(boy)
    boywsm = [0] * len(boy)
    boyzwt = [0] * len(boy)
    boyldt = [0] * len(boy)
    boyytx = [0] * len(boy)
    boycp = [0] * len(boy)
    boyscore = [0] * len(boy)

    for i in range(len(boy)):
        boybmi[i] = scoreboy.bmis(boy['身高'][i], boy['体重'][i])
        boyfhl[i] = scoreboy.feihuoliangs(boy['年级编号'][i], boy['肺活量'][i])
        boywsm[i] = scoreboy.duanpaos(boy['年级编号'][i], boy['50米跑'][i])
        boyzwt[i] = scoreboy.zuoweitis(boy['年级编号'][i], boy['坐位体前屈'][i])
        boyldt[i] = scoreboy.lidingtiaos(boy['年级编号'][i], boy['立定跳远'][i])
        boyytx[i] = scoreboy.yintixiangshangs(boy['年级编号'][i], boy['引体向上'][i])
        boycp[i] = scoreboy.changpaos(boy['年级编号'][i], boy['1000米跑'][i])
        boyscore[i] = boybmi[i] + boyfhl[i] + boywsm[i] + boyzwt[i] + boyldt[i] + boyytx[i] + boycp[i]

    boy['BMI成绩'] = boybmi
    boy['肺活量成绩'] = boyfhl
    boy['50米跑成绩'] = boywsm
    boy['坐位体前屈成绩'] = boyzwt
    boy['立定跳远成绩'] = boyldt
    boy['引体向上成绩'] = boyytx
    boy['1000米跑成绩'] = boycp
    boy['总成绩'] = boyscore

    order = ['ID', '年级编号', '专业', '账号', '民族', '姓名', '身高', '体重', 'BMI成绩', '肺活量', '肺活量成绩',
             '50米跑', '50米跑成绩', '立定跳远', '立定跳远成绩', '坐位体前屈', '坐位体前屈成绩', '1000米跑',
             '1000米跑成绩', '引体向上', '引体向上成绩', '总成绩']
    boy = boy[order]

    girlbmi = [0] * len(girl)
    girlfhl = [0] * len(girl)
    girlwsm = [0] * len(girl)
    girlzwt = [0] * len(girl)
    girlldt = [0] * len(girl)
    girlywq = [0] * len(girl)
    girlcp = [0] * len(girl)
    girlscore = [0] * len(girl)
    for i in range(len(girl)):
        girlbmi[i] = scoregirl.bmis(girl['身高'][i], girl['体重'][i])
        girlfhl[i] = scoregirl.feihuoliangs(girl['年级编号'][i], girl['肺活量'][i])
        girlwsm[i] = scoregirl.duanpaos(girl['年级编号'][i], girl['50米跑'][i])
        girlzwt[i] = scoregirl.zuoweitis(girl['年级编号'][i], girl['坐位体前屈'][i])
        girlldt[i] = scoregirl.lidingtiaos(girl['年级编号'][i], girl['立定跳远'][i])
        girlywq[i] = scoregirl.yangwoqizuos(girl['年级编号'][i], girl['一分钟仰卧起坐'][i])
        girlcp[i] = scoregirl.changpaos(girl['年级编号'][i], girl['800米跑'][i])
        girlscore[i] = girlbmi[i] + girlfhl[i] + girlwsm[i] + girlzwt[i] + girlldt[i] + girlywq[i] + girlcp[i]
    girl['BMI成绩'] = girlbmi
    girl['肺活量成绩'] = girlfhl
    girl['50米跑成绩'] = girlwsm
    girl['坐位体前屈成绩'] = girlzwt
    girl['立定跳远成绩'] = girlldt
    girl['一分钟仰卧起坐成绩'] = girlywq
    girl['800米跑成绩'] = girlcp
    girl['总成绩'] = girlscore
    order = ['ID', '年级编号', '专业', '账号', '民族', '姓名', '身高', '体重', 'BMI成绩', '肺活量', '肺活量成绩',
             '50米跑', '50米跑成绩', '立定跳远', '立定跳远成绩', '坐位体前屈', '坐位体前屈成绩', '800米跑',
             '800米跑成绩', '一分钟仰卧起坐', '一分钟仰卧起坐成绩', '总成绩']
    girl = girl[order]

    account = boy['账号'].values
    account = np.append(account, girl['账号'].values)
    password = ['S1284987'] * len(account)
    permission = [1] * len(account)
    account = pd.DataFrame({'账号': account, '密码': password, '权限': permission})
    boy.to_excel('2017boy.xls', index=False)
    girl.to_excel('2017girl.xls', index=False)
    account.to_excel('2017account.xls', index=False)







